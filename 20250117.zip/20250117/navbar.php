<?php ?>
<header>
    <nav class="navbar">
        <div class="logo" >
            <img src="FTS logo.png" alt=""></div>
        <input type="text" class="search-bar" placeholder="Search...">
        <div class="nav-buttons">
            <form action="home.php">
                <button id="home-button" class="nav-button">Home</button></form>
            <form action="contact.php">
                <button id="contact-button" class="nav-button" >Contact</button></form>
            <form action="account.php">
                <button id="openmodal" class="nav-button">account</button></form>
            <form action="login.php">
                <button id="login-button" class="login-button">Login</button>
            </form>
        </div>
    </nav>
</header>

